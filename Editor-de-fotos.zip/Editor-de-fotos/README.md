# Editor de fotos v0.3

Proyecto IO
UPC EETAC
Ingeniería Telemática / de Sistemas de Telecomunicación

Se trata de un editor de fotos .png / .jpg

Se puede hacer un collage con 4 fotos, invertir una foto, cambiarle el color o enmarcarla

Tener la foto siempre en la carpeta del proyecto /bin/debug.

Disfruten del código :)
